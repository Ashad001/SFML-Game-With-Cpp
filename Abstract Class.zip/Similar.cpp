#include "Similar.h"
void similar::Draw() {
	cout << "Error calling the Draw function for either entity or player class";
}
sf::FloatRect similar::SetHitBox() {
	cout << "Error setting hitbox  for either entity or player class";
}
