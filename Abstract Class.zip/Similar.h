#pragma once
class similar {
public:
	virtual void Draw() = 0;
	virtual sf::FloatRect SetHitBox() = 0;
};
