#pragma once
class similar {
	sf::Window* i_win;
	sf::Sprite body;
public:
	Grid* grids;
	virtual void Draw() = 0;
	virtual sf::FloatRect SetHitBox() = 0;
};
